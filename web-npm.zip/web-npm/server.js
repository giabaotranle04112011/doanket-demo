const express = require('express');
const app = express();

// Cho phép đọc file trong public
app.use(express.static('public'));

// chạy server
app.listen(3000, '0.0.0.0', () => {
    console.log('🔥 Server chạy tại http://localhost:3000');
});